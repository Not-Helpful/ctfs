We have provided a docker setup to help you run/test this locally.

Just run docker-compose up in this folder, then connect to the challenge on localhost via port 13337