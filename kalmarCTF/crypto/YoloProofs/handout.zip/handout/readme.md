Zero-knowledge proofs are pretty dank bro,
in early 90ties Goldwasser et al. showed that you prove every satisfied NP relation in ZK,
in late 2010s blockchain people showed us this result extends to false NP instances.
Cool stuff.


Included source code, as well as the binary running on remote.